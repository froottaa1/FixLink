package com.fixlink.app

import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions

object FirebaseRepository {
    fun isConfigured(): Boolean = FirebaseApp.getApps(App.instance).isNotEmpty()
    private fun auth(): FirebaseAuth = FirebaseAuth.getInstance()
    private fun db(): FirebaseFirestore = FirebaseFirestore.getInstance()

    fun login(email: String, password: String, callback: (Boolean, String?) -> Unit) {
        if (!isConfigured()) {
            callback(false, "إعداد Firebase غير مكتمل. أضف ملف google-services.json ثم أعد البناء.")
            return
        }
        auth().signInWithEmailAndPassword(email, password)
            .addOnSuccessListener { callback(true, null) }
            .addOnFailureListener { callback(false, it.localizedMessage ?: "تعذر تسجيل الدخول") }
    }

    fun currentUid(): String? = if (isConfigured()) auth().currentUser?.uid else null

    fun loadMyTechnician(callback: (Technician?) -> Unit) {
        val uid = currentUid() ?: run { callback(null); return }
        db().collection("technicians").document(uid).get()
            .addOnSuccessListener { doc -> callback(doc.toObject(Technician::class.java)?.copy(id = uid)) }
            .addOnFailureListener { callback(null) }
    }

    fun saveTechnician(technician: Technician, callback: (Boolean, String?) -> Unit) {
        val uid = currentUid()
        if (uid == null) { callback(false, "لا يوجد حساب مسجل أو لم يتم إعداد Firebase"); return }
        val data = hashMapOf(
            "id" to uid, "name" to technician.name, "specialty" to technician.specialty,
            "type" to technician.type, "address" to technician.address, "phone" to technician.phone,
            "latitude" to technician.latitude, "longitude" to technician.longitude,
            "available" to technician.available, "ratingAverage" to technician.ratingAverage,
            "ratingCount" to technician.ratingCount, "updatedAt" to FieldValue.serverTimestamp()
        )
        db().collection("technicians").document(uid).set(data, SetOptions.merge())
            .addOnSuccessListener { callback(true, null) }
            .addOnFailureListener { callback(false, it.localizedMessage ?: "فشل الحفظ") }
    }

    fun loadTechnicians(callback: (List<Technician>, String?) -> Unit) {
        if (!isConfigured()) {
            callback(emptyList(), "إعداد Firebase غير مكتمل. أضف google-services.json.")
            return
        }
        db().collection("technicians").whereEqualTo("available", true).get()
            .addOnSuccessListener { result ->
                callback(result.documents.mapNotNull { d -> d.toObject(Technician::class.java)?.copy(id = d.id) }, null)
            }
            .addOnFailureListener { callback(emptyList(), it.localizedMessage ?: "تعذر تحميل الفنيين") }
    }

    fun loadReviews(technicianId: String, callback: (List<Review>) -> Unit) {
        if (!isConfigured()) { callback(emptyList()); return }
        db().collection("technicians").document(technicianId).collection("reviews")
            .orderBy("createdAt").limit(50).get()
            .addOnSuccessListener { result -> callback(result.toObjects(Review::class.java)) }
            .addOnFailureListener { callback(emptyList()) }
    }

    fun addReview(technicianId: String, rating: Int, comment: String, callback: (Boolean, String?) -> Unit) {
        val uid = currentUid()
        if (uid == null) { callback(false, "يلزم تسجيل الدخول لإضافة تقييم"); return }
        val technicianRef = db().collection("technicians").document(technicianId)
        val reviewRef = technicianRef.collection("reviews").document(uid)
        db().runTransaction { transaction ->
            val technician = transaction.get(technicianRef)
            val oldCount = technician.getLong("ratingCount") ?: 0L
            val oldAverage = technician.getDouble("ratingAverage") ?: 0.0
            val oldReview = transaction.get(reviewRef)
            val oldRating = if (oldReview.exists()) (oldReview.getLong("rating") ?: 0L).toInt() else 0
            val newCount = if (oldReview.exists()) oldCount else oldCount + 1
            val newAverage = if (newCount == 0L) rating.toDouble()
                else ((oldAverage * oldCount - oldRating + rating) / newCount)
            transaction.set(reviewRef, mapOf(
                "userId" to uid, "rating" to rating, "comment" to comment,
                "createdAt" to System.currentTimeMillis()
            ))
            transaction.update(technicianRef, mapOf("ratingCount" to newCount, "ratingAverage" to newAverage))
        }.addOnSuccessListener { callback(true, null) }
            .addOnFailureListener { callback(false, it.localizedMessage ?: "تعذر حفظ التقييم") }
    }

    fun logout() { if (isConfigured()) auth().signOut() }
}
