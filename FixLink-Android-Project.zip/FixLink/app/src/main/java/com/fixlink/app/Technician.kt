package com.fixlink.app

data class Technician(
    val id: String = "",
    val name: String = "",
    val specialty: String = "",
    val type: String = "maintenance",
    val address: String = "",
    val phone: String = "",
    val latitude: Double? = null,
    val longitude: Double? = null,
    val available: Boolean = true,
    val ratingAverage: Double = 0.0,
    val ratingCount: Long = 0L
)
data class Review(
    val userId: String = "",
    val rating: Int = 5,
    val comment: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
