package com.fixlink.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.fixlink.app.databinding.ActivitySettingsBinding

class SettingsActivity : AppCompatActivity() {
    private lateinit var b: ActivitySettingsBinding
    // استبدل بيانات الدعم ببيانات إدارة التطبيق قبل النشر.
    private val supportPhone = ""
    private val supportEmail = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.btnSupportCall.setOnClickListener {
            if (supportPhone.isBlank()) message("لم يتم تحديد رقم الدعم بعد")
            else startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$supportPhone")))
        }
        b.btnSupportWhatsapp.setOnClickListener {
            if (supportPhone.isBlank()) message("لم يتم تحديد رقم واتساب الدعم بعد")
            else startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/${supportPhone.filter { it.isDigit() }}")))
        }
        b.btnSupportEmail.setOnClickListener {
            if (supportEmail.isBlank()) message("لم يتم تحديد بريد الدعم بعد")
            else startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:$supportEmail")))
        }
    }
    private fun message(text: String) = android.widget.Toast.makeText(this, text, android.widget.Toast.LENGTH_SHORT).show()
}
