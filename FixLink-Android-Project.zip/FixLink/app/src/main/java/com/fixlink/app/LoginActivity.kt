package com.fixlink.app

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.fixlink.app.databinding.ActivityLoginBinding

class LoginActivity : AppCompatActivity() {
    private lateinit var b: ActivityLoginBinding
    private val accountType by lazy { intent.getStringExtra("account_type") ?: "maintenance" }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.tvAccountType.text = if (accountType == "software") "دخول فني السوفتوير والبرمجة" else "دخول فني الصيانة"
        b.btnLogin.setOnClickListener { login() }
    }
    private fun login() {
        val email = b.etEmail.text?.toString()?.trim().orEmpty()
        val password = b.etPassword.text?.toString().orEmpty()
        b.etEmail.error = null
        b.etPassword.error = null
        if (email.isBlank() || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            b.etEmail.error = "أدخل بريدًا إلكترونيًا صحيحًا"; return
        }
        if (password.length < 6) { b.etPassword.error = "كلمة المرور يجب ألا تقل عن 6 أحرف"; return }
        b.progress.visibility = View.VISIBLE
        b.btnLogin.isEnabled = false
        FirebaseRepository.login(email, password) { success, error ->
            b.progress.visibility = View.GONE
            b.btnLogin.isEnabled = true
            if (success) {
                startActivity(Intent(this, DashboardActivity::class.java).putExtra("account_type", accountType))
                finish()
            } else b.tvLoginMessage.text = error
        }
    }
}
