package com.fixlink.app

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.fixlink.app.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var b: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.btnClient.setOnClickListener { startActivity(Intent(this, TechnicianListActivity::class.java)) }
        b.btnMaintenance.setOnClickListener { openLogin("maintenance") }
        b.btnSoftware.setOnClickListener { openLogin("software") }
        b.btnSettings.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
    }
    private fun openLogin(type: String) {
        startActivity(Intent(this, LoginActivity::class.java).putExtra("account_type", type))
    }
}
