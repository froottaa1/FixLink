package com.fixlink.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.fixlink.app.databinding.ItemTechnicianBinding
import java.util.Locale

class TechnicianAdapter(
    private val context: Context,
    private var items: List<Technician>,
    private val onDetails: (Technician) -> Unit
) : RecyclerView.Adapter<TechnicianAdapter.Holder>() {
    var userLocation: android.location.Location? = null
    class Holder(val b: ItemTechnicianBinding) : RecyclerView.ViewHolder(b.root)
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        Holder(ItemTechnicianBinding.inflate(LayoutInflater.from(parent.context), parent, false))
    override fun getItemCount() = items.size
    override fun onBindViewHolder(holder: Holder, position: Int) {
        val t = items[position]; val b = holder.b
        b.tvName.text = t.name
        b.tvSpecialty.text = if (t.type == "software") "سوفتوير وبرمجة • ${t.specialty}" else "صيانة • ${t.specialty}"
        b.tvRating.text = "★ ${String.format(Locale.US, "%.1f", t.ratingAverage)} (${t.ratingCount} تقييم)"
        b.tvAddress.text = "العنوان: ${t.address.ifBlank { "غير محدد" }}"
        val distance = if (userLocation != null && t.latitude != null && t.longitude != null) {
            val target = android.location.Location("technician").apply {
                latitude = t.latitude; longitude = t.longitude
            }
            val km = userLocation!!.distanceTo(target) / 1000.0
            "المسافة: ${String.format(Locale.US, "%.1f", km)} كم"
        } else "المسافة غير متاحة"
        b.tvDistance.text = distance
        b.btnCall.setOnClickListener { if (t.phone.isNotBlank()) context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${t.phone}"))) }
        b.btnWhatsapp.setOnClickListener {
            val number = t.phone.filter { it.isDigit() }.removePrefix("00")
            if (number.isNotBlank()) {
                val uri = Uri.parse("https://wa.me/$number")
                context.startActivity(Intent(Intent.ACTION_VIEW, uri))
            }
        }
        b.btnMap.setOnClickListener {
            if (t.latitude != null && t.longitude != null) {
                val uri = Uri.parse("geo:${t.latitude},${t.longitude}?q=${t.latitude},${t.longitude}(${Uri.encode(t.name)})")
                context.startActivity(Intent(Intent.ACTION_VIEW, uri))
            } else if (t.address.isNotBlank()) {
                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=${Uri.encode(t.address)}")))
            }
        }
        b.btnDetails.setOnClickListener { onDetails(t) }
    }
    fun submitList(newItems: List<Technician>) { items = newItems; notifyDataSetChanged() }
}
