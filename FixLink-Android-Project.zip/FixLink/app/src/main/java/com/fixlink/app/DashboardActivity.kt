package com.fixlink.app

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.fixlink.app.databinding.ActivityDashboardBinding

class DashboardActivity : AppCompatActivity() {
    private lateinit var b: ActivityDashboardBinding
    private val type by lazy { intent.getStringExtra("account_type") ?: "maintenance" }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityDashboardBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.etSpecialty.setText(if (type == "software") "سوفتوير وبرمجة" else "صيانة")
        FirebaseRepository.loadMyTechnician { t ->
            if (t != null) {
                b.etName.setText(t.name); b.etSpecialty.setText(t.specialty)
                b.etAddress.setText(t.address); b.etPhone.setText(t.phone)
                b.etLatitude.setText(t.latitude?.toString().orEmpty())
                b.etLongitude.setText(t.longitude?.toString().orEmpty())
                b.switchAvailable.isChecked = t.available
            }
        }
        b.btnSave.setOnClickListener { save() }
        b.btnLogout.setOnClickListener {
            FirebaseRepository.logout()
            finish()
        }
    }
    private fun save() {
        val name = b.etName.text?.toString()?.trim().orEmpty()
        val specialty = b.etSpecialty.text?.toString()?.trim().orEmpty()
        val address = b.etAddress.text?.toString()?.trim().orEmpty()
        val phone = b.etPhone.text?.toString()?.trim().orEmpty()
        if (name.isBlank()) { b.etName.error = "الاسم مطلوب"; return }
        if (phone.isBlank()) { b.etPhone.error = "رقم الهاتف مطلوب"; return }
        val lat = b.etLatitude.text?.toString()?.toDoubleOrNull()
        val lon = b.etLongitude.text?.toString()?.toDoubleOrNull()
        if ((lat == null) != (lon == null)) {
            b.tvDashboardMessage.text = "أدخل خط العرض والطول معًا أو اتركهما فارغين"; return
        }
        if (lat != null && (lat !in -90.0..90.0 || lon !in -180.0..180.0)) {
            b.tvDashboardMessage.text = "إحداثيات الموقع غير صحيحة"; return
        }
        val technician = Technician(
            id = FirebaseRepository.currentUid().orEmpty(), name = name, specialty = specialty,
            type = type, address = address, phone = phone, latitude = lat, longitude = lon,
            available = b.switchAvailable.isChecked
        )
        b.btnSave.isEnabled = false
        FirebaseRepository.saveTechnician(technician) { ok, error ->
            b.btnSave.isEnabled = true
            b.tvDashboardMessage.text = if (ok) "تم حفظ بياناتك بنجاح" else error
        }
    }
}
