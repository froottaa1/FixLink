package com.fixlink.app

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.fixlink.app.databinding.ActivityTechnicianDetailBinding

class TechnicianDetailActivity : AppCompatActivity() {
    private lateinit var b: ActivityTechnicianDetailBinding
    private val technicianId by lazy { intent.getStringExtra("technician_id").orEmpty() }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityTechnicianDetailBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.ratingSlider.addOnChangeListener { _, value, _ -> b.tvRatingValue.text = "التقييم: ${value.toInt()} نجوم" }
        FirebaseRepository.loadTechnicians { list, _ ->
            val t = list.firstOrNull { it.id == technicianId }
            if (t != null) {
                b.tvDetailName.text = t.name
                b.tvDetailInfo.text = "التخصص: ${t.specialty}\nالنوع: ${if (t.type == "software") "سوفتوير وبرمجة" else "صيانة"}\nالعنوان: ${t.address}\nالهاتف: ${t.phone}\nالتقييم: ${t.ratingAverage} من 5 (${t.ratingCount} تقييم)"
            }
        }
        refreshReviews()
        b.btnSubmitReview.setOnClickListener {
            val comment = b.etComment.text?.toString()?.trim().orEmpty()
            if (comment.isBlank()) { b.etComment.error = "اكتب تعليقًا قبل الإرسال"; return@setOnClickListener }
            b.btnSubmitReview.isEnabled = false
            FirebaseRepository.addReview(technicianId, b.ratingSlider.value.toInt(), comment) { ok, error ->
                b.btnSubmitReview.isEnabled = true
                b.tvReviewMessage.text = if (ok) "تم إرسال تقييمك" else error
                if (ok) { b.etComment.setText(""); refreshReviews() }
            }
        }
    }
    private fun refreshReviews() {
        FirebaseRepository.loadReviews(technicianId) { reviews ->
            b.tvReviews.text = if (reviews.isEmpty()) "لا توجد تقييمات بعد" else reviews.joinToString("\n\n") {
                "★ ${it.rating}/5\n${it.comment}"
            }
        }
    }
}
