package com.fixlink.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.fixlink.app.databinding.ActivityTechniciansBinding
import com.google.android.gms.location.LocationServices

class TechnicianListActivity : AppCompatActivity() {
    private lateinit var b: ActivityTechniciansBinding
    private lateinit var adapter: TechnicianAdapter
    private var all = listOf<Technician>()
    private var currentType = "all"
    private var location: Location? = null
    private val permission = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (it.values.any { granted -> granted }) getLocation()
        else loadTechnicians()
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityTechniciansBinding.inflate(layoutInflater)
        setContentView(b.root)
        adapter = TechnicianAdapter(this, emptyList()) { t ->
            startActivity(Intent(this, TechnicianDetailActivity::class.java).putExtra("technician_id", t.id))
        }
        b.recyclerTechnicians.layoutManager = LinearLayoutManager(this)
        b.recyclerTechnicians.adapter = adapter
        b.filterGroup.check(R.id.filterAll)
        b.filterGroup.addOnButtonCheckedListener { _, checkedId, checked ->
            if (checked) {
                currentType = when (checkedId) {
                    R.id.filterMaintenance -> "maintenance"
                    R.id.filterSoftware -> "software"
                    else -> "all"
                }
                applyFilters()
            }
        }
        b.etSearch.addTextChangedListener(SimpleTextWatcher { applyFilters() })
        requestLocationIfNeeded()
    }
    private fun requestLocationIfNeeded() {
        val fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (fine || coarse) getLocation()
        else permission.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
    }
    private fun getLocation() {
        try {
            LocationServices.getFusedLocationProviderClient(this).lastLocation
                .addOnSuccessListener { location = it; adapter.userLocation = it; loadTechnicians() }
                .addOnFailureListener { loadTechnicians() }
        } catch (_: SecurityException) { loadTechnicians() }
    }
    private fun loadTechnicians() {
        b.listProgress.visibility = android.view.View.VISIBLE
        FirebaseRepository.loadTechnicians { list, error ->
            b.listProgress.visibility = android.view.View.GONE
            all = if (location == null) list else list.sortedBy { t ->
                if (t.latitude == null || t.longitude == null) Float.MAX_VALUE else {
                    val target = Location("target").apply { latitude = t.latitude; longitude = t.longitude }
                    location!!.distanceTo(target)
                }
            }
            if (error != null) android.widget.Toast.makeText(this, error, android.widget.Toast.LENGTH_LONG).show()
            applyFilters()
        }
    }
    private fun applyFilters() {
        val query = b.etSearch.text?.toString()?.trim().orEmpty()
        val result = all.filter { t ->
            (currentType == "all" || t.type == currentType) &&
                (query.isBlank() || t.name.contains(query, true) || t.specialty.contains(query, true) || t.address.contains(query, true))
        }
        adapter.submitList(result)
        b.tvEmpty.visibility = if (result.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
    }
}

class SimpleTextWatcher(private val changed: () -> Unit) : android.text.TextWatcher {
    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { changed() }
    override fun afterTextChanged(s: android.text.Editable?) {}
}
